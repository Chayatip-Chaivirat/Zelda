﻿using var game = new Zelda.Game1();
game.Run();
